/**
 * Copyright (c) 2014, 2017, Oracle and/or its affiliates.
 * The Universal Permissive License (UPL), Version 1.0
 */
/*
 * Your incidents ViewModel code goes here
 */
define(['ojs/ojcore', 'knockout', 'jquery', 'ojs/ojknockout', 'promise', 'ojs/ojtable', 'ojs/ojarraytabledatasource', 'ojs/ojmodel',
    'ojs/ojtable', 'ojs/ojpagingcontrol', 'ojs/ojcollectiontabledatasource', 'ojs/ojcollapsible', 'ojs/ojinputtext', 'ojs/ojDialog',     'ojs/ojtable', 'ojs/ojpagingcontrol', 'ojs/ojcollectiontabledatasource', 'ojs/ojcollapsible', 'ojs/ojinputtext', 'ojs/ojDialog', 'ojs/ojinputnumber'],
        function (oj, ko, $) {

            function IncidentsViewModel() {
                var self = this;

                self.trackerTemplateItem = ko.observable();

                self.EmployeeId = ko.observable();
                self.FirstName = ko.observable();
                self.LastName = ko.observable();
                self.Email = ko.observable();
                self.Salary = ko.observable();
                



                self.showEditDialog = function (itemId, data, event) {
                    console.log("showEditDialog called");

                    self.EmployeeId(itemId);
                    self.FirstName(data.FirstName);
                    self.LastName(data.LastName);
                    self.Email(data.Email);
                    self.Salary(data.Salary);


                    $('#editDialog').ojDialog('open');
                };

                self.saveTemplateItem = function () {
                    //var trackerObj = ko.utils.unwrapObservable(self.trackerTemplateItem);
                    //if (!this._showComponentValidationErrors(trackerObj)) {
                    //    return;
                    //}

                    console.log("save succesfull!!");

                }
                
                self._showComponentValidationErrors = function (trackerObj) {
                    trackerObj.showMessages();
                    if (trackerObj.focusOnFirstInvalid())
                        return false;
                    return true;
                };



                //***********************************************************
                //******************** EMPLOYEES  **************************
                //***********************************************************

                self.EmployeeURL = 'http://127.0.0.1:7101/tech17REST/rest/v0/employee';
                self.EmployeeCol = ko.observable();
                self.fetch = function (successCallBack) {
                    self.EmployeeCol().fetch({
                        success: successCallBack,
                        error: function (jqXHR, textStatus, errorThrown) {
                            console.log('Error in fetch: ' + textStatus);
                        }
                    });
                }

                parseEmployee = function (response) {
                    return {EmployeeId: response['EmployeeId'],
                        FirstName: response['FirstName'],
                        LastName: response['LastName'],
                        Email: response['Email'],
                        PhoneNumber: response['PhoneNumber'],
                        Salary: response['Salary']};
                };

                var Employee = oj.Model.extend({
                    urlRoot: self.EmployeeURL,
                    parse: parseEmployee,
                    idAttribute: 'EmployeeId'
                });

                var myEmployee = new Employee();
                var EmployeeCollection = oj.Collection.extend({
                    url: self.EmployeeURL,
                    fetchSize: 10,
                    model: myEmployee
                });
                self.EmployeeCol(new EmployeeCollection());
                self.EmployeeDS = new oj.PagingTableDataSource(new oj.CollectionTableDataSource(self.EmployeeCol()));


                self.handleActivated = function (info) {
                    // Implement if needed
                };

                self.handleAttached = function (info) {
                    // Implement if needed
                };


                self.handleBindingsApplied = function (info) {

                    console.log('handleBindingsApplied start');
                    //console.log(self.selectionListener(null));
                    var table = document.getElementById('tableEmployee');
                    //console.log('handleBindingsApplied called2 ' + table);
                    table.addEventListener('selectionChanged', self.selectionListener);

                    var table2 = document.getElementById('table');
                    //ko.applyBindings(vm, table);
                    console.log('handleBindingsApplied called2 ' + table2);
                    table2.addEventListener('selectionChanged', self.selectionListener);


                    //           table.addEventListener('selectionChanged', self.caca);
                    console.log('handleBindingsApplied end');
                };

                self.handleDetached = function (info) {
                    // Implement if needed
                };
            }

            return new IncidentsViewModel();
        }
);
