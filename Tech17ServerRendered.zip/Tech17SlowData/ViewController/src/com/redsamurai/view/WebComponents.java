package com.redsamurai.view;

import javax.el.ELContext;
import javax.el.ExpressionFactory;
import javax.el.ValueExpression;

import javax.faces.application.Application;
import javax.faces.context.FacesContext;

import oracle.adf.view.rich.component.rich.RichPopup;
import oracle.adf.view.rich.context.AdfFacesContext;

import org.apache.myfaces.trinidad.event.SelectionEvent;

public class WebComponents {
    public WebComponents() {
        super();
    }
    
    private RichPopup popup;

   
    public void whenInvoceItemChanges(SelectionEvent selectionEvent)
    {
      ADFUtil.invokeEL("#{bindings.EmployeesView1.collectionModel.makeCurrent}", new Class[] {SelectionEvent.class},
                       new Object[] { selectionEvent });
      
      RichPopup.PopupHints hints = new RichPopup.PopupHints();
      hints.add(RichPopup.PopupHints.HintTypes.HINT_ALIGN, RichPopup.PopupHints.AlignTypes.ALIGN_AFTER_END);
      this.getPopup().show(hints);
      
      AdfFacesContext.getCurrentInstance().addPartialTarget(this.getPopup());
      
        

    }

    public void setPopup(RichPopup popup)
    {
      this.popup = popup;
    }

    public RichPopup getPopup()
    {
      return popup;
    }
    
    
    public Object resolvElDC(String data) {
            FacesContext fc = FacesContext.getCurrentInstance();
            Application app = fc.getApplication();
            ExpressionFactory elFactory = app.getExpressionFactory();
            ELContext elContext = fc.getELContext();
            ValueExpression valueExp =
                elFactory.createValueExpression(elContext, "#{data." + data + ".dataProvider}", Object.class);
            return valueExp.getValue(elContext);
        }

    
}
