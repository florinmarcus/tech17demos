package com.redsamurai.view;

import org.apache.myfaces.trinidad.event.PollEvent;
import java.io.Serializable;

import javax.el.ELContext;
import javax.el.ExpressionFactory;
import javax.el.ValueExpression;

import javax.faces.application.Application;
import javax.faces.context.FacesContext;

import oracle.adf.view.rich.component.rich.output.RichActiveOutputText;

import oracle.adf.view.rich.context.AdfFacesContext;

import oracle.jbo.ViewObject;

import org.apache.myfaces.trinidad.event.PollEvent;
import com.redsamurai.model.AppModuleImpl;



public class Live {
    public Live() {
    }

    public void poll(PollEvent pollEvent) {
        System.out.println("poll fired...");
        AppModuleImpl am = (AppModuleImpl)resolvElDC("AppModuleDataControl");

        ViewObject vo = am.getLiveChartVO1();
        vo.executeQuery();
        
    }
    
    public Object resolvElDC(String data) {
            FacesContext fc = FacesContext.getCurrentInstance();
            Application app = fc.getApplication();
            ExpressionFactory elFactory = app.getExpressionFactory();
            ELContext elContext = fc.getELContext();
            ValueExpression valueExp =
                elFactory.createValueExpression(elContext, "#{data." + data + ".dataProvider}", Object.class);
            return valueExp.getValue(elContext);
        }

       
}
