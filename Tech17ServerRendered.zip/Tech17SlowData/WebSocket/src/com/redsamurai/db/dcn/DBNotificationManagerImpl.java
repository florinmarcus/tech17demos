package com.redsamurai.db.dcn;

import com.redsamurai.websocket.model.Job;
import com.redsamurai.websocket.service.WebSocketService;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import javax.naming.InitialContext;
import javax.naming.NamingException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;

import javax.sql.DataSource;

import oracle.jdbc.OracleConnection;
import oracle.jdbc.OracleStatement;
import oracle.jdbc.dcn.DatabaseChangeEvent;
import oracle.jdbc.dcn.DatabaseChangeListener;
import oracle.jdbc.dcn.DatabaseChangeRegistration;

public class DBNotificationManagerImpl extends HttpServlet {
    @SuppressWarnings("compatibility:3626507617957540494")
    private static final long serialVersionUID = -899796428604382698L;

    private static DatabaseChangeRegistration dcr = null;
    private static OracleConnection conn = null;
    private static DatabaseChangeListener listener = null;
    
    @Override
    public void init() throws ServletException {
        try {
            startListening();
            
            System.out.println("DB listener started.....");
        } catch (Exception e) {
            e.printStackTrace();
            throw new IllegalStateException(e);
        }
    }
    
    @Override
    public void destroy() {
        try {
            dcr.removeListener(listener);
            conn.unregisterDatabaseChangeNotification(dcr);
            conn.close();
            
            System.out.println("DB listener destroyed.....");
        } catch (SQLException e) {
            e.printStackTrace();
            throw new IllegalStateException(e);
        }
    }
    
    public void startListening() throws Exception {
        if(true)
            return;
        
        conn = getConnection();
        Properties prop = new Properties();
        prop.setProperty(OracleConnection.DCN_NOTIFY_ROWIDS, "true");
        dcr = conn.registerDatabaseChangeNotification(prop);

        try {
            listener = new DatabaseChangeListener() {
                public void onDatabaseChangeNotification(DatabaseChangeEvent dce) {
                    System.out.println("DB table updated");
                    
                    List<Job> jobs = getDbData();
                    for (Job job : jobs) {
                        System.out.println("JOB ID: " + job.getJobId() + " : " + job.getJobAvgSal());
                    }
                    WebSocketService.notifyClient(jobs);
                }
            };
            dcr.addListener(listener);

            Statement stmt = conn.createStatement();
            ((OracleStatement)stmt).setDatabaseChangeRegistration(dcr);
            ResultSet rs = stmt.executeQuery(getNotificationSql());
            
            ArrayList<Job> jobs = new ArrayList<Job>();
            while (rs.next()) {
                Job job = new Job();
                job.setJobId(rs.getString("job_id"));
                job.setJobAvgSal(rs.getInt("avg_salary"));
                jobs.add(job);
                
                System.out.println("JOB ID: " + job.getJobId() + " : " + job.getJobAvgSal());
            }
            
            rs.close();
            stmt.close();
        } catch (SQLException ex) {
            if (conn != null) {
                conn.unregisterDatabaseChangeNotification(dcr);
                conn.close();
            }
            throw ex;
        }
    }
    
    public List<Job> getDbData() {
        ArrayList<Job> jobs = new ArrayList<Job>();
        PreparedStatement stmt = null;
        ResultSet rs = null;
        try {
            stmt = conn.prepareStatement(getNotificationSql());
            rs = stmt.executeQuery();
            while (rs.next()) {
                Job job = new Job();
                job.setJobId(rs.getString("job_id"));
                job.setJobAvgSal(rs.getInt("avg_salary"));
                jobs.add(job);
            }         
        } catch (SQLException e) {
            throw new IllegalStateException(e);
        } finally {
            try {
                if(rs != null)
                    rs.close();
                if(stmt != null)
                    stmt.close();

            } catch (SQLException e) {}
        }
        return jobs;
    }

    public String getNotificationSql() {
        return "SELECT job_id," + 
        "  ROUND(AVG(salary)) AS avg_salary" + 
        " FROM employees" + 
        " WHERE job_id = 'IT_PROG'" + 
        " OR job_id    = 'ST_CLERK'" + 
        " OR job_id    = 'SA_REP'" + 
        " OR job_id    = 'SH_CLERK'" + 
        " OR job_id    = 'FI_ACOUNT'" + 
        " GROUP BY job_id";
    }
    
    public static final OracleConnection getConnection() {
        InitialContext ic;
        Connection con = null;
        try {
            ic = new InitialContext();
            DataSource ds = (DataSource) ic.lookup("jdbc/HrDS");
            con = ds.getConnection();

            return (OracleConnection) con;
        } catch (NamingException e) {
           throw new IllegalStateException(e);

        } catch (SQLException e) {
            throw new IllegalStateException(e);
        }
    }
}
