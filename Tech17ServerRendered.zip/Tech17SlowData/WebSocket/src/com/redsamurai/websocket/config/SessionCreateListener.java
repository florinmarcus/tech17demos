package com.redsamurai.websocket.config;

import javax.servlet.ServletRequestEvent;
import javax.servlet.ServletRequestListener;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;

public class SessionCreateListener implements ServletRequestListener {
    public SessionCreateListener() {
        super();
    }

    public void requestInitialized(ServletRequestEvent sre) {
        HttpServletRequest request = (HttpServletRequest) sre.getServletRequest();
        
        Cookie[] cookie = request.getCookies();
        if (cookie != null && cookie.length > 0) {
            for (Cookie cookie1 : cookie) {
                request.getSession(true).setAttribute(cookie1.getName() + "__", cookie1.getValue());
                System.out.println("Register COOKIE for WebSocket: " + cookie1.getName() + " : " + cookie1.getValue());
            }
        }
    }
    
    public void requestDestroyed(ServletRequestEvent sre) {
        // nothing
    }
}
