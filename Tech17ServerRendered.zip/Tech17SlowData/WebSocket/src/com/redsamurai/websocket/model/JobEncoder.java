package com.redsamurai.websocket.model;

import java.util.List;

import javax.json.Json;
import javax.json.JsonArray;
import javax.json.JsonArrayBuilder;
import javax.json.JsonObject;

import javax.websocket.EncodeException;
import javax.websocket.Encoder;
import javax.websocket.EndpointConfig;

public class JobEncoder implements Encoder.Text<List<Job>> {
    public JobEncoder() {
        super();
    }

    @Override
    public String encode(List<Job> jobs) throws EncodeException {
        JsonArrayBuilder jsonArrayBuilder = Json.createArrayBuilder();
        for (int i = 0; i < jobs.size(); i++) {
            Job job = jobs.get(i);
            JsonObject jsonObject = Json.createObjectBuilder()
                            .add("jobId", job.getJobId())
                            .add("jobAvgSal", job.getJobAvgSal())
                            .build();
            jsonArrayBuilder.add(jsonObject);
        }
        JsonArray jsonArray = jsonArrayBuilder.build();
        
        return jsonArray.toString();
    }

    @Override
    public void init(EndpointConfig endpointConfig) {
        // TODO Implement this method
    }

    @Override
    public void destroy() {
        // TODO Implement this method
    }
}
