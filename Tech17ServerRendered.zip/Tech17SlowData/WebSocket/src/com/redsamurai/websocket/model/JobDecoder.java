package com.redsamurai.websocket.model;

import java.io.StringReader;

import java.util.ArrayList;
import java.util.List;

import javax.json.Json;
import javax.json.JsonArray;
import javax.json.JsonObject;

import javax.websocket.DecodeException;
import javax.websocket.Decoder;
import javax.websocket.EndpointConfig;

public class JobDecoder implements Decoder.Text<List<Job>> {
    public JobDecoder() {
        super();
    }

    @Override
    public List<Job> decode(String message) throws DecodeException {        
        JsonArray jsonArray = Json.createReader(new StringReader(message)).readArray();
        List<Job> jobs = new ArrayList<>();
        for(int i = 0; i < jsonArray.size(); i++) {
            JsonObject jsonObject = jsonArray.getJsonObject(i);
            Job job = new Job();
            job.setJobId(jsonObject.getString("jobId"));
            job.setJobAvgSal(jsonObject.getInt("jobAvgSal"));
        
            jobs.add(job);      
        }
        
        return jobs;
    }

    @Override
    public boolean willDecode(String string) {
        // TODO Implement this method
        return false;
    }

    @Override
    public void init(EndpointConfig endpointConfig) {
        // TODO Implement this method
    }

    @Override
    public void destroy() {
        // TODO Implement this method
    }
}
