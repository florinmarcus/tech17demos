package com.redsamurai.websocket.model;


public class Job {
    private String jobId;
    private Integer jobAvgSal;
    
    public Job() {
        super();
    }

    public void setJobId(String jobId) {
        this.jobId = jobId;
    }

    public String getJobId() {
        return jobId;
    }

    public void setJobAvgSal(Integer jobAvgSal) {
        this.jobAvgSal = jobAvgSal;
    }

    public Integer getJobAvgSal() {
        return jobAvgSal;
    }
}
