package com.redsamurai.websocket.service;

import com.redsamurai.websocket.config.GetHttpSessionConfigurator;
import com.redsamurai.websocket.model.Job;
import com.redsamurai.websocket.model.JobDecoder;
import com.redsamurai.websocket.model.JobEncoder;

import java.io.IOException;

import java.util.ArrayList;
import java.util.List;
import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;

import javax.servlet.http.HttpSession;

import javax.websocket.EncodeException;
import javax.websocket.EndpointConfig;
import javax.websocket.OnClose;
import javax.websocket.OnError;
import javax.websocket.OnMessage;
import javax.websocket.OnOpen;
import javax.websocket.Session;
import javax.websocket.server.ServerEndpoint;

import org.apache.http.HttpEntity;
import org.apache.http.client.CookieStore;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.impl.client.BasicCookieStore;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.cookie.BasicClientCookie;
import org.apache.http.util.EntityUtils;


@ServerEndpoint(value = "/service", decoders = JobDecoder.class, encoders = JobEncoder.class,
                configurator = GetHttpSessionConfigurator.class)

public class WebSocketService {
    final static Queue<Session> queue = new ConcurrentLinkedQueue<>();

    private HttpSession httpSession;
    MyThread mythread = null;
    
    public WebSocketService() {
        super();
    }

    @OnOpen
    public void open(Session session, EndpointConfig config) {
        //System.out.println(session.getId() + ", open.getMaxIdleTimeout : " + session.getMaxIdleTimeout() +
        //                   ", getOpenSessions: " + session.getOpenSessions() + ", " + session.getClass());

        queue.add(session);

        httpSession = (HttpSession) config.getUserProperties().get(HttpSession.class.getName());
        if (httpSession != null) {
            //System.out.println("Cookie JSESSIONID__: " + httpSession.getAttribute("JSESSIONID__"));
            ///System.out.println("HTTP Session ID: " + httpSession.getId());
        }

        if(mythread == null) {
            mythread = new MyThread(this);
            mythread.start();
        }
        //System.out.println("thread started....");


    }

    @OnClose
    public void closedConnection(Session session, EndpointConfig config) {
      //  System.out.println(session.getId() + ", open.getMaxIdleTimeout : " + session.getMaxIdleTimeout() +
      //                     ", getOpenSessions: " + session.getOpenSessions() + ", " + session.getClass());
        queue.remove(session);

        try {
            handleLogOut(httpSession);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @OnError
    public void error(Session session, Throwable t) {
     //  System.out.println(session.getId() + ", open.getMaxIdleTimeout : " + session.getMaxIdleTimeout() +
      //                     ", getOpenSessions: " + session.getOpenSessions() + ", " + session.getClass());
        queue.remove(session);
        t.printStackTrace();
    }

    @OnMessage
    public void processMessage(Session session, Object msg) {

    }

    public static void notifyClient(List<Job> jobs) {
       // System.out.println("notifyClient.... " + jobs);
        for (Session session : queue) {
            try {
                session.getBasicRemote().sendObject(jobs);
            } catch (EncodeException e) {
                throw new IllegalStateException(e);
            } catch (IOException e) {
                throw new IllegalStateException(e);
            }
        }
    }

    public String handleLogOut(HttpSession httpSession_) throws Exception {
        if (httpSession_ !=
            null) {
            // Create a local instance of cookie store
            CookieStore cookieStore = new BasicCookieStore();
            // Populate cookies if needed
            BasicClientCookie cookie =
new BasicClientCookie("JSESSIONID", (String) httpSession_.getAttribute("JSESSIONID__"));
            cookie.setDomain("127.0.0.1");
            cookie.setPath("/");
            cookieStore.addCookie(cookie);

            CloseableHttpClient httpClient = HttpClients.custom()
                                                        .setDefaultCookieStore(cookieStore)
                                                        .setSSLHostnameVerifier(new NoopHostnameVerifier())
                                                        .build();

            HttpGet httpGet = new HttpGet("http://127.0.0.1:7101/dashboard/adfAuthentication?logout=true");
            CloseableHttpResponse response = httpClient.execute(httpGet);
            try {
            //    System.out.println("Response Status: " + response.getStatusLine());

                HttpEntity entity = response.getEntity();
                EntityUtils.consume(entity);
            } finally {
                response.close();
            }


           // System.out.println("Session closed for ID: " + httpSession_.getAttribute("JSESSIONID__"));
        }

        return null;
    }

    class MyThread extends Thread {

        private WebSocketService wss;

        public MyThread(WebSocketService wss) {
            this.wss = wss;
        }

        @Override
        public void run() {

            //System.out.println("thread runs....");
            ArrayList<Job> jobs = new ArrayList<Job>();
            Job job1 = new Job();
            job1.setJobId("IT_PROG");
            job1.setJobAvgSal(42);
            Job job2 = new Job();
            job2.setJobId("SH_CLERK");
            job2.setJobAvgSal(55);
            Job job3 = new Job();
            job3.setJobAvgSal(2);
            job3.setJobId("SA_REP");
            Job job4 = new Job();
            job4.setJobAvgSal(10);
            job4.setJobId("ST_CLERK");

            jobs.add(job1);
            jobs.add(job2);
            jobs.add(job3);
            jobs.add(job4);

            try {
                while (true) {
                    try {
                        Thread.sleep(4000);
                    } catch (InterruptedException e) {
                    }

                    wss.notifyClient(jobs);


                    job1.setJobAvgSal(job1.getJobAvgSal() - 1);
                    job2.setJobAvgSal(job2.getJobAvgSal() - 1);
                    job3.setJobAvgSal(job3.getJobAvgSal() + 1);
                    job4.setJobAvgSal(job4.getJobAvgSal() + 1);
                }
            } catch (Throwable e) {
                
                e.printStackTrace();

            }

        }
    }
}
