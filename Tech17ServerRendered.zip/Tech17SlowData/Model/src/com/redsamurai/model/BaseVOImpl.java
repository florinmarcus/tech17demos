package com.redsamurai.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import oracle.jbo.ViewCriteria;
import oracle.jbo.server.QueryCollection;
import oracle.jbo.server.SQLBuilder;
import oracle.jbo.server.ViewDefImpl;
import oracle.jbo.server.ViewObjectImpl;
import oracle.jbo.server.ViewRowImpl;
import oracle.jbo.server.ViewRowSetImpl;

public class BaseVOImpl extends ViewObjectImpl {
    public BaseVOImpl(String string, ViewDefImpl viewDefImpl) {
        super(string, viewDefImpl);
    }

    public BaseVOImpl() {
        super();
    }
    

    /**
     * method override, to allow logging
     * @param qc
     * @param params
     * @param stmt
     * @throws SQLException
     */
    @Override
    protected void bindParametersForCollection(QueryCollection qc, Object[] params,
                                               PreparedStatement stmt) throws SQLException {

        //logQueryStatementAndBindParameters(qc, params);
        if(qc != null)
            System.out.println("Firing query for '" + this.getName() + "'. Thread ID: " + Thread.currentThread().getId());
        super.bindParametersForCollection(qc, params, stmt);
        
        boolean slow = true;
        long curr = System.currentTimeMillis();

        try {
            //verify if you need a slow demo or not
            PreparedStatement pstmt =
                this.getDBTransaction()
                .createPreparedStatement("select prop_value from tech17_settings where prop_name='SLOW'", -1);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                if ("FALSE".equalsIgnoreCase(rs.getString("prop_value"))) {
                    slow = false;
                }
            }
        } catch (SQLException sqle) {
            // TODO: Add catch code
            //sqle.printStackTrace();
        }
        
        if(slow) 
        {
            int sleepInterval = 2000;
            if(this.getName().indexOf("EmployeesView1") >=0 ) {
                sleepInterval = 6000;
            }
            else if(this.getName().indexOf("DepartmentsView1") >=0 ) {
                sleepInterval = 5000;
            }
            else if(this.getName().indexOf("RegionsView1") >=0 ) {
                sleepInterval = 4000;
            }
            else if(this.getName().indexOf("JobHistoryView1") >=0 ) {
                sleepInterval = 3000;
            }
            else if(this.getName().indexOf("JobsView1") >=0 ) {
                sleepInterval = 2000;
            }
            else if(this.getName().indexOf("LocationsView1") >=0 ) {
                sleepInterval = 1000;
            }
            
            
                
            try {
                Thread.currentThread().sleep(sleepInterval);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        if(qc != null)
            System.out.println("Query  for '" + this.getName() +  "' completed in " + (System.currentTimeMillis() - curr) + "miliseconds. Thread ID: " + Thread.currentThread().getId());

    }

    /**
     * method used to introspect the query produced at runtime by the vo.
     * @param qc
     * @param params
     */
    private void logQueryStatementAndBindParameters(QueryCollection qc, Object[] params) {
        String vrsiName = null;
        if (qc != null) {
            ViewRowSetImpl vrsi = qc.getRowSetImpl();
            vrsiName = vrsi.isDefaultRS() ? "<Default>" : vrsi.getName();
        }
        String voName = getName();
        String voDefName = getDefFullName();
        if (qc != null) {
            System.out.println("---- " + " [Exec query for VO=" + voName + ", RS=" + vrsiName + "]----");
        } else {
            System.out.println("---- " + " [Exec COUNT query for VO=" + voName + "]----");
        }
        System.out.println("VO Definition Name =" + voDefName);

        String dbVCs = appliedCriteriaString(ViewCriteria.CRITERIA_MODE_QUERY);
        if (dbVCs != null && !dbVCs.isEmpty()) {
            System.out.println("Applied Database VCs = " + dbVCs);
        }

        String memVCs = appliedCriteriaString(ViewCriteria.CRITERIA_MODE_CACHE);
        if (memVCs != null && !memVCs.isEmpty()) {
            System.out.println("Applied In-Memory VCs =" + memVCs);
        }

        String bothVCs = appliedCriteriaString(ViewCriteria.CRITERIA_MODE_QUERY | ViewCriteria.CRITERIA_MODE_CACHE);
        if (bothVCs != null && !bothVCs.isEmpty()) {
            System.out.println("Applied 'Both' VCs = " + bothVCs);
        }

        System.out.println("Generated query : " + getQuery() );

        if (params != null) {
            if (getBindingStyle() == SQLBuilder.BINDING_STYLE_ORACLE_NAME) {
                Map<String, Object> bindsMap = new HashMap<String, Object>(params.length);
                for (Object param : params) {
                    Object[] nameValue = (Object[]) param;
                    String name = (String) nameValue[0];
                    Object value = nameValue[1];
                    bindsMap.put(name, value);
                }
                System.out.println("Bind Variables " + bindsMap);
            }
        }
        
       
       
                

                
    }


    private String appliedCriteriaString(int mode) {
        ViewCriteria[] appliedCriterias = getApplyViewCriterias(mode);
        String result = "";
        if (appliedCriterias != null && appliedCriterias.length > 0) {
            List<String> list = new ArrayList<String>(appliedCriterias.length);
            for (ViewCriteria vc : appliedCriterias) {
                list.add(vc.getName());
            }
            result = list.toString();
        }
        return result;
    }


    @Override
    public ViewRowImpl createInstanceFromResultSet(QueryCollection queryCollection, ResultSet resultSet) {
        ViewRowImpl vr = super.createInstanceFromResultSet(queryCollection, resultSet);

       /**
            if (vr != null)
                System.out.println("\n----[VO " + getName() + " fetched " + vr.getKey() + "]");
            else
                System.out.println("\n----[VO " + getName() + " fetched " + vr + "]");
        **/

        return vr;
    }
    
    
}
